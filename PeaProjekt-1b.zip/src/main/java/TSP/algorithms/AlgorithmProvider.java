package TSP.algorithms;

public interface AlgorithmProvider {
    Algorithm getAlgorithm();
}
