package TSP.algorithms;

public class IncorrectDataException extends Exception {
    IncorrectDataException(String message) {
        super(message);
    }
}
