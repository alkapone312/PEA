package TSP.measurement;

public class TimerException extends Exception {
    TimerException(String message) {
        super(message);
    }
}
