package TSP.data;

public interface DataProvider {
    Matrix getData();
}
